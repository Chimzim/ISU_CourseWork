In order to run hw3.js move the file into your desired folder.
Next open up Node.js command prompt
Simply change your directory using the cd command to where you just placed hw3.js
use node hw3.js and the program should run instructing you on its behavior from there :)