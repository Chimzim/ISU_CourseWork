const student = {
	name: "Chim",
	class: "SE 319",
	year: 2020
};

const stud = {
	<div>
		<p>Student name: {studnet.name}</p>
		<p>Class name: {student.class}</p>
		<p>Year: {student.year}</p>
	</div>
};
	
ReactDOM.render(para, document.getElementById("app"));