class App extends React.Component {
	render(){
		return {
			<div>
			<h3>Class:SE319</h3>
			<h3>Lab Activity 4</h3>
			<p>This is class component.</p>
			</div>
		};
	}
}

ReactDOM.render(<App />, document.gerElementById("app"));
			
		