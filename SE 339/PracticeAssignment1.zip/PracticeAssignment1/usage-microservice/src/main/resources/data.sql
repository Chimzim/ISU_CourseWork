INSERT INTO usage_statistic (id, created_date, speed, fuel_level, rotations_per_minute, latitude, longitude, driver_id, driver_fullname, vehicle_id, vehicle_license_plate) VALUES
  (0, '2018-12-19 06:22:00', 59.6, 0.4, 9, 42.0284, -93.6509, 0, 'Gigi Wentworth (877-CASH-NOW)', 0, 'MPASTA');
