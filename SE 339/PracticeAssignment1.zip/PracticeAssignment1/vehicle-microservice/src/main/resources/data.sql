INSERT INTO vehicle (id, make, model, model_year, registration_id) VALUES
  (0, 'Ford', 'Taurus', 1996, 0),
  (1, 'Ford', 'Fusion', 2011, 1),
  (2, 'Ford', 'F150', 2003, 2);

INSERT INTO registration (id, license_plate, licensed_to) VALUES
  (0, 'MPASTA', 'Gianni Pasta Emporium'),
  (1, 'HANYOU', 'Your Local Chinese'),
  (2, 'HAMMER', 'Joe Construction Corp');
