package com.se421.paths.transforms;

import com.ensoftcorp.atlas.core.query.Q;

public interface ProgramGraphTransform {

	public Q transform(Q graph);

}
