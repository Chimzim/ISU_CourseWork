In the zip file contains 3 Folders
-Node modules
-public
-src
************************************
In order to run the program open up Node.js command prompt and change your directory to be where you have extracted
the zip file to. Once this has been done you should be able to use the command npm run build_task1. From there go into 
the public folder and open index.html. If this doesn't work delete the Node modules folder. and use the commmand
npm install. Then call npm run build_task1 and finally open up index.html.